<?php
require 'vendor/autoload.php';
use Laminas\Ldap\Ldap;

if(isset($_GET['uid']) && isset($_GET['ou'])) {
    $uid = $_GET['uid'];
    $ou = $_GET['ou'];
    
    $domini = 'dc=fjeclot,dc=net';
    $opcions = [
        'host' => 'zend-vimasa.fjeclot.net',
        'username' => "cn=admin,$domini",
        'password' => 'fjeclot',
        'bindRequiresDn' => true,
        'accountDomainName' => 'fjeclot.net',
        'baseDn' => 'dc=fjeclot,dc=net',
    ];
    $ldap = new Ldap($opcions);
    $ldap->bind();
    
    $dn = "uid=$uid,ou=$ou,dc=fjeclot,dc=net";
    if($ldap->delete($dn)) {
        echo "Usuari $uid esborrat correctament de la unitat organitzativa $ou.";
    } else {
        echo "Error a l'esborrar l'usuari $uid de la unitat organitzativa $ou.";
    }
}
?>

<form method="get" action="esborra.php">
    <label for="uid">UID:</label>
    <input type="text" name="uid" id="uid" required><br>

    <label for="ou">Unitat Organitzativa:</label>
    <input type="text" name="ou" id="ou" required><br>

    <input type="submit" value="Esborra">
</form>
