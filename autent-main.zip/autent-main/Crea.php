<?php
require 'vendor/autoload.php';
use Laminas\Ldap\Attribute;
use Laminas\Ldap\Ldap;





ini_set('display_errors', 0);

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    # Dades de la nova entrada
    $uid = $_GET['uid'];
    $unorganitzativa = $_GET['unorganitzativa'];
    $uidnumber_id = $_GET['uidnumber_id'];
    $gidNumber = $_GET['gidNumber'];
    $dir_pers = $_GET['dir_pers'];
    $shell = $_GET['shell'];
    $cn = $_GET['cn'];
    $sn = $_GET['sn'];
    $givenName = $_GET['givenName'];
    $PostalAdress = $_GET['PostalAdress'];
    $mobile = $_GET['mobile'];
    $telephone = $_GET['telephone'];
    $title = $_GET['title'];
    $descripcio = $_GET['descripcio'];
    
    # Afegint la nova entrada
    $objcl = ['top', 'posixAccount', 'person', 'inetOrgPerson'];
    $domini = 'dc=fjeclot,dc=net';
    $opcions = [
        'host' => 'zend-vimasa.fjeclot.net',
        'username' => "cn=admin,$domini",
        'password' => 'fjeclot',
        'bindRequiresDn' => true,
        'accountDomainName' => 'fjeclot.net',
        'baseDn' => 'dc=fjeclot,dc=net',
    ];
    $ldap = new Ldap($opcions);
    $ldap->bind();
    $nova_entrada = [];
    Attribute::setAttribute($nova_entrada, 'objectClass', $objcl);
    Attribute::setAttribute($nova_entrada, 'uid', $uid);
    Attribute::setAttribute($nova_entrada, 'uidNumber', $uidnumber_id);
    Attribute::setAttribute($nova_entrada, 'gidNumber', $gidNumber);
    Attribute::setAttribute($nova_entrada, 'homeDirectory', $dir_pers);
    Attribute::setAttribute($nova_entrada, 'loginShell', $shell);
    Attribute::setAttribute($nova_entrada, 'cn', $cn);
    Attribute::setAttribute($nova_entrada, 'sn', $sn);
    Attribute::setAttribute($nova_entrada, 'givenName', $givenName);
    Attribute::setAttribute($nova_entrada, 'mobile', $mobile);
    Attribute::setAttribute($nova_entrada, 'postalAddress', $PostalAdress);
    Attribute::setAttribute($nova_entrada, 'telephoneNumber', $telephone);
    Attribute::setAttribute($nova_entrada, 'title', $title);
    Attribute::setAttribute($nova_entrada, 'description', $descripcio);
    $dn = 'uid=' . $uid . ',ou=' . $unorganitzativa . ',dc=fjeclot,dc=net';
    if ($ldap->add($dn, $nova_entrada)) {
        echo "Usuari creat";
    }
}
?>

