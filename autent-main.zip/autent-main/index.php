<html>
	<head>
		<title>
			PÀGINA WEB INICIAL DE L'APLICACIÓ
		</title>
	</head>
	<body>
		<h1> APLICACIÓ D'ACCÉS A BASES DE DADES LDAP</h1>
		<h2> DAW2 M08UF2 M08UF3 </h2>
		<h3> Autor: dacomo2021daw2</h3>
		<h3> Correu: dacomo2021daw2@protonmail.com</h3>
		<h3> Github: https://github.com/dacomo2021daw2/autent.git</h3>
		<a href="http://zend-vimasa.fjeclot.net/autent/login.php">Inicia sessió</a>
	</body>
</html>