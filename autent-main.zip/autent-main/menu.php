<html>
	<head>
		<title>
			PÀGINA WEB DEL MENÚ PRINCIPAL DE L'APLICACIÓ D'ACCÉS A BASES DE DADES LDAP
		</title>
	</head>
	<body>
		<h2> MENÚ PRINCIPAL DE L'APLICACIÓ D'ACCÉS A BASES DE DADES LDAP</h2>
		<h3> <b>En construcció!!!!!!!!!!!</b> </h3>
		<a href="http://zend-vimasa.fjeclot.net/autent/index.php">Torna a la pàgina inicial</a>
		<a href="http://zend-vimasa.fjeclot.net/autent/crea.html">Afegeix Dades</a>
		<a href="http://zend-vimasa.fjeclot.net/autent/esborra.php">Elimina Dades</a>
		<a href="http://zend-vimasa.fjeclot.net/autent/modifica.php">Modifica Dades</a>
		<a href="http://zend-vimasa.fjeclot.net/autent/mostra.html">Mostra Dades</a>
		
		
		
	</body>
</html>