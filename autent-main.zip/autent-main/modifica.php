<?php
require 'vendor/autoload.php';
use Laminas\Ldap\Ldap;

if(isset($_GET['uid']) && isset($_GET['ou']) && isset($_GET['atributo']) && isset($_GET['valor'])) {
    $uid = $_GET['uid'];
    $ou = $_GET['ou'];
    $atributo = $_GET['atributo'];
    $valor = $_GET['valor'];
    
    $domini = 'dc=fjeclot,dc=net';
    $opcions = [
        'host' => 'zend-vimasa.fjeclot.net',
        'username' => "cn=admin,$domini",
        'password' => 'fjeclot',
        'bindRequiresDn' => true,
        'accountDomainName' => 'fjeclot.net',
        'baseDn' => 'dc=fjeclot,dc=net',
    ];
    $ldap = new Ldap($opcions);
    $ldap->bind();
    
    $dn = "uid=$uid,ou=$ou,dc=fjeclot,dc=net";
    $entry = [
        $atributo => $valor,
    ];
    if($ldap->update($dn, $entry)) {
        echo "Atributo $atributo modificado correctamente para el usuario $uid en la unidad organizativa $ou.";
    } else {
        echo "Error al modificar el atributo $atributo para el usuario $uid en la unidad organizativa $ou.";
    }
}
?>

<form method="get" action="modifica.php">
    <label for="uid">UID:</label>
    <input type="text" name="uid" id="uid" required><br>

    <label for="ou">Unitat Organitzativa:</label>
    <input type="text" name="ou" id="ou" required><br>
    
    <label>Atributo:</label><br>
    <input type="radio" name="atributo" value="uidNumber" id="uidNumber">
    <label for="uidNumber">uidNumber</label><br>
    
    <input type="radio" name="atributo" value="gidNumber" id="gidNumber">
    <label for="gidNumber">gidNumber</label><br>
    
    <input type="radio" name="atributo" value="homeDirectory" id="homeDirectory">
    <label for="homeDirectory">Directori personal</label><br>
    
    <input type="radio" name="atributo" value="loginShell" id="loginShell">
    <label for="loginShell">Shell</label><br>
    
    <input type="radio" name="atributo" value="cn" id="cn">
    <label for="cn">cn</label><br>
    
    <input type="radio" name="atributo" value="sn" id="sn">
    <label for="sn">sn</label><br>
    
    <input type="radio" name="atributo" value="givenName" id="givenName">
    <label for="givenName">givenName</label><br>
    
    <input type="radio" name="atributo" value="postalAddress" id="postalAddress">
    <label for="postalAddress">PostalAdress</label><br>
    
    <input type="radio" name="atributo" value="mobile" id="mobile">
    <label for="mobile">mobile</label><br>
    
    <input type="radio" name="atributo" value="telephoneNumber" id="telephoneNumber">
    <label for="telephoneNumber">telephoneNumber</label><br>
    
    <input type="radio" name="atributo" value="title" id="title">
    <label for="title">title</label><br>
    
    <input type="radio" name="atributo" value="description" id="description">
    <label for="description">description</label><br>
    
    <label for="valor">Nuevo valor:</label>
    <input type="text" name="valor" id="valor" required><br>
    
    <input type="submit" value="Modificar">
    </form>